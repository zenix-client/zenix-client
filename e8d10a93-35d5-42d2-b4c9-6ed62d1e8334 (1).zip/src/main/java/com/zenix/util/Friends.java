package com.zenix.util;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public final class Friends {
  private Friends() {}
  private static final Set<String> NAMES = new TreeSet<>();
  private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zenix-friends.json");

  public static boolean is(String name) { return name != null && NAMES.contains(name.toLowerCase(Locale.ROOT)); }
  public static boolean add(String n) { boolean r = NAMES.add(n.toLowerCase(Locale.ROOT)); save(); return r; }
  public static boolean remove(String n) { boolean r = NAMES.remove(n.toLowerCase(Locale.ROOT)); save(); return r; }
  public static Collection<String> all() { return Collections.unmodifiableSet(NAMES); }

  public static void load() {
    try {
      if (!Files.exists(FILE)) return;
      for (JsonElement e : JsonParser.parseString(Files.readString(FILE)).getAsJsonArray()) NAMES.add(e.getAsString().toLowerCase(Locale.ROOT));
    } catch (Exception e) { e.printStackTrace(); }
  }
  static void save() {
    try { JsonArray a = new JsonArray(); for (String n : NAMES) a.add(n); Files.writeString(FILE, a.toString()); }
    catch (Exception e) { e.printStackTrace(); }
  }
}
