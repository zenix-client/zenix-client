package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import java.util.Random;

/** Combat modules re-implemented from behaviour seen in the Obsidian reference (names/settings only, no code reused). */
public final class CombatExtras {
  private CombatExtras() {}
  static final Category C = Category.COMBAT;
  public static void register(List<Module> l) { l.add(new AimAssist()); l.add(new AimBot()); l.add(new ItemRelease()); l.add(new AutoExplosion()); l.add(new AutoSwap()); }

  static PlayerEntity bestPlayer(MinecraftClient mc, double range, double fov, boolean walls) {
    PlayerEntity best = null; double bd = Double.MAX_VALUE; PlayerEntity me = mc.player;
    for (PlayerEntity e : mc.world.getPlayers()) {
      if (e == me || !e.isAlive() || e.isSpectator() || Friends.is(e.getName().getString()) || CombatModules.AntiBot.isBot(e)) continue;
      if (me.distanceTo(e) > range || (!walls && !me.canSee(e))) continue;
      Vec3d to = e.getBoundingBox().getCenter().subtract(me.getEyePos());
      float yaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90), pitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z)));
      double ang = Math.hypot(MathHelper.wrapDegrees(yaw - me.getYaw()), pitch - me.getPitch());
      if (ang > fov / 2) continue;
      if (ang < bd) { bd = ang; best = e; }
    }
    return best;
  }

  public static class AimAssist extends Module {
    final Random r = new Random();
    public AimAssist() {
      super("AimAssist", C, "Gently pulls your crosshair toward the nearest player in your view");
      add(new Setting("Max Speed", 6, 1, 30)).add(new Setting("Distance", 4.0, 2.0, 6.0, 0.1)).add(new Setting("FOV", 70, 10, 180, 5)).add(new Setting("Noise", 0.5, 0, 3, 0.1)).add(new Setting("Only While Attacking", true));
    }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.currentScreen != null || (get("Only While Attacking").on() && !mc.options.attackKey.isPressed())) return;
      PlayerEntity t = bestPlayer(mc, get("Distance").value, get("FOV").value, false);
      if (t == null) return;
      CombatModules.Aura.face(mc, t, get("Max Speed").f());
      float n = get("Noise").f();
      if (n > 0) { mc.player.setYaw(mc.player.getYaw() + (r.nextFloat() - 0.5f) * n); mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + (r.nextFloat() - 0.5f) * n, -90f, 90f)); }
    }
  }

  public static class AimBot extends Module {
    public AimBot() {
      super("AimBot", C, "Aims a drawn bow with target lead and arrow drop");
      add(new Setting("Distance", 40, 8, 80, 2)).add(new Setting("FOV", 90, 10, 180, 5)).add(new Setting("Max Speed", 25, 2, 90)).add(new Setting("Lead Target", true));
    }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; ItemStack u = p.getActiveItem();
      if (!p.isUsingItem() || !u.isOf(Items.BOW)) return;
      PlayerEntity t = bestPlayer(mc, get("Distance").value, get("FOV").value, false);
      if (t == null) return;
      float pull = net.minecraft.item.BowItem.getPullProgress(p.getItemUseTime());
      double speed = Math.max(0.5, pull * 3.0), dist = p.distanceTo(t), ticks = dist / speed;
      Vec3d aim = t.getBoundingBox().getCenter();
      if (get("Lead Target").on()) aim = aim.add(t.getX() - t.prevX, 0, t.getZ() - t.prevZ).add((t.getX() - t.prevX) * ticks, 0, (t.getZ() - t.prevZ) * ticks);
      aim = aim.add(0, 0.5 * 0.05 * ticks * ticks, 0); // gravity drop of arrows
      Vec3d to = aim.subtract(p.getEyePos());
      float yaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90), pitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z))), m = get("Max Speed").f();
      p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(yaw - p.getYaw()), -m, m));
      p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitch - p.getPitch(), -m, m), -90f, 90f));
    }
  }

  public static class ItemRelease extends Module {
    public ItemRelease() {
      super("ItemRelease", C, "Releases a bow/trident automatically once it is fully drawn");
      add(new Setting("Bow", true)).add(new Setting("Trident", true)).add(new Setting("Extra Delay (ticks)", 0, 0, 10));
    }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; if (!p.isUsingItem()) return;
      ItemStack s = p.getActiveItem(); int t = p.getItemUseTime(), extra = get("Extra Delay (ticks)").i();
      boolean go = (get("Bow").on() && s.isOf(Items.BOW) && t >= 20 + extra) || (get("Trident").on() && s.isOf(Items.TRIDENT) && t >= 10 + extra);
      if (go) mc.interactionManager.stopUsingItem(p);
    }
  }

  public static class AutoExplosion extends Module {
    int cd;
    public AutoExplosion() { super("AutoExplosion", C, "Breaks nearby end crystals automatically"); add(new Setting("Range", 4.5, 2, 6, 0.1)).add(new Setting("Delay (ticks)", 3, 1, 20)); }
    @Override public void onTick(MinecraftClient mc) {
      if (--cd > 0 || mc.currentScreen != null) return;
      PlayerEntity p = mc.player; EndCrystalEntity best = null; double bd = get("Range").value;
      for (Entity e : mc.world.getEntities()) if (e instanceof EndCrystalEntity c && e.isAlive()) { double d = p.distanceTo(e); if (d <= bd) { bd = d; best = c; } }
      if (best == null) return;
      mc.interactionManager.attackEntity(p, best); p.swingHand(Hand.MAIN_HAND); cd = get("Delay (ticks)").i();
    }
  }

  /** Off-hand swap between two items by keybind (bind a key to this module). */
  public static class AutoSwap extends Module {
    static final String[] ITEMS = {"Totem", "Shield", "Golden Apple", "Enchanted Apple"};
    public AutoSwap() {
      super("AutoSwap", C, "Swaps your off-hand between two chosen items (one press = one swap)");
      oneShot = true; add(new Setting("First Item", "Totem", ITEMS)).add(new Setting("Second Item", "Shield", ITEMS));
    }
    static Item item(String m) { return switch (m) { case "Totem" -> Items.TOTEM_OF_UNDYING; case "Shield" -> Items.SHIELD; case "Golden Apple" -> Items.GOLDEN_APPLE; default -> Items.ENCHANTED_GOLDEN_APPLE; }; }
    @Override public void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance(); enabled = false;
      if (mc.player == null || mc.currentScreen != null) return;
      Item a = item(get("First Item").mode()), b = item(get("Second Item").mode());
      Item want = mc.player.getOffHandStack().isOf(a) ? b : a;
      int slot = Inv.any(s -> s.isOf(want));
      if (slot < 0) { Chat.info("AutoSwap: no matching item in the inventory"); return; }
      mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, Inv.screenSlot(slot), 40, SlotActionType.SWAP, mc.player);
    }
  }
}
