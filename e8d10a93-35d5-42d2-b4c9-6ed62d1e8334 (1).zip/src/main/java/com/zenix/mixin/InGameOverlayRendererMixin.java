package com.zenix.mixin;

import com.zenix.modules.RenderExtras;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
  @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
  private static void zenix$noFire(CallbackInfo ci) { if (RenderExtras.Removals.fire()) ci.cancel(); }
  @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true)
  private static void zenix$noWall(CallbackInfo ci) { if (RenderExtras.Removals.wall()) ci.cancel(); }
}
