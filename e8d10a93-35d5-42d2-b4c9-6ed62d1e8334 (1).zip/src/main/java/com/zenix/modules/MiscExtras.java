package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import java.util.*;

public final class MiscExtras {
  private MiscExtras() {}
  static final Category C = Category.MISC;
  public static void register(List<Module> l) { l.add(new DeathCoord()); l.add(new LeaveTracker()); l.add(new EcOpen()); }

  public static class DeathCoord extends Module {
    Vec3d last; boolean reported;
    public DeathCoord() { super("DeathCoord", C, "Prints where you died"); add(new Setting("Copy To Clipboard", true)); }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.currentScreen instanceof DeathScreen) {
        if (!reported && last != null) {
          reported = true; String s = (int) last.x + " " + (int) last.y + " " + (int) last.z;
          Chat.info("You died at " + s + " (" + Waypoints.dim() + ")");
          if (get("Copy To Clipboard").on()) mc.keyboard.setClipboard(s);
        }
      } else { reported = false; if (mc.player.isAlive()) last = mc.player.getPos(); }
    }
  }

  /** Reports the last seen position of players that disappear from your render distance while still online. */
  public static class LeaveTracker extends Module {
    static final class Seen { String name; Vec3d pos; }
    final Map<UUID, Seen> seen = new HashMap<>();
    public LeaveTracker() { super("LeaveTracker", C, "Prints the last position of players who leave your loaded area"); }
    @Override public void onDisable() { seen.clear(); }
    @Override public void onTick(MinecraftClient mc) {
      Set<UUID> now = new HashSet<>();
      for (PlayerEntity p : mc.world.getPlayers()) {
        if (p == mc.player) continue; now.add(p.getUuid());
        Seen s = seen.computeIfAbsent(p.getUuid(), k -> new Seen()); s.name = p.getName().getString(); s.pos = p.getPos();
      }
      Iterator<Map.Entry<UUID, Seen>> it = seen.entrySet().iterator();
      while (it.hasNext()) {
        var e = it.next(); if (now.contains(e.getKey())) continue;
        if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(e.getKey()) != null)
          Chat.info(e.getValue().name + " left your range at " + (int) e.getValue().pos.x + " " + (int) e.getValue().pos.y + " " + (int) e.getValue().pos.z);
        it.remove();
      }
    }
  }

  public static class EcOpen extends Module {
    public EcOpen() { super("EcOpen", C, "Opens the nearest ender chest (bind a key)"); oneShot = true; add(new Setting("Distance", 4, 1, 6)); }
    @Override public void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance(); enabled = false;
      if (mc.player == null || mc.currentScreen != null) return;
      int r = get("Distance").i(); BlockPos best = null; double bd = Double.MAX_VALUE;
      for (BlockPos p : BlockPos.iterateOutwards(mc.player.getBlockPos(), r, r, r))
        if (mc.world.getBlockState(p).isOf(Blocks.ENDER_CHEST)) { double d = p.getSquaredDistance(mc.player.getEyePos()); if (d < bd) { bd = d; best = p.toImmutable(); } }
      if (best == null) { Chat.info("No ender chest within " + r + " blocks"); return; }
      mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(best), Direction.UP, best, false));
    }
  }
}
