package com.zenix.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class Chat {
  private Chat() {}
  public static void info(String msg) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc == null || mc.inGameHud == null) return;
    mc.inGameHud.getChatHud().addMessage(Text.literal("\u00a75[ZENIX]\u00a7r " + msg));
  }
}
