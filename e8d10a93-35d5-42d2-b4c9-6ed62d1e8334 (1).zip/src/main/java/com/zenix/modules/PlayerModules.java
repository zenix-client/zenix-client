package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.List;
import java.util.Random;

public final class PlayerModules {
  private PlayerModules() {}
  static final Category C = Category.PLAYER;

  public static void register(List<Module> l) {
    l.add(new AntiAFK()); l.add(new AutoExp()); l.add(new AutoRespawn()); l.add(new AutoTool()); l.add(new ChestStealer());
    l.add(new Nuker()); PlayerExtras.register(l); l.add(new Optimize());
    String hook = "Needs a mixin/accessor whose 1.21.4 names are not verified yet";
    for (String n : new String[]{"AutoUse", "ChorusControl", "ItemFixSwap", "ItemScroller", "KTL.eave", "NoClipRView", "NoTrace"}) l.add(Module.planned(n, C, "Not implemented yet"));
    l.add(Module.planned("FakePlayer", C, "Local-only dummy entity; entity-spawn API not verified yet"));
    for (String n : new String[]{"MultiTask", "SpeedMine"}) l.add(Module.planned(n, C, hook));
  }

  public static class AntiAFK extends Module {
    int t; final Random r = new Random();
    public AntiAFK() { super("AntiAFK", C, "Small periodic actions so AFK kicks do not trigger"); add(new Setting("Interval (s)", 20, 5, 120, 5)).add(new Setting("Action", "Jump", "Jump", "Rotate", "Swing")); }
    @Override public void onTick(MinecraftClient mc) {
      mc.options.jumpKey.setPressed(false);
      if (++t < get("Interval (s)").i() * 20) return;
      t = 0;
      if (get("Action").is("Jump")) mc.options.jumpKey.setPressed(true);
      else if (get("Action").is("Rotate")) mc.player.setYaw(mc.player.getYaw() + (r.nextBoolean() ? 20 : -20));
      else mc.player.swingHand(Hand.MAIN_HAND);
    }
    @Override public void onDisable() { MinecraftClient.getInstance().options.jumpKey.setPressed(false); }
  }

  public static class AutoRespawn extends Module {
    int t;
    public AutoRespawn() { super("AutoRespawn", C, "Respawns automatically on the death screen"); add(new Setting("Delay (ticks)", 10, 0, 60)); }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.currentScreen instanceof DeathScreen) { if (++t >= get("Delay (ticks)").i()) { mc.player.requestRespawn(); t = 0; } } else t = 0;
    }
  }

  public static class AutoTool extends Module {
    int prev = -1;
    public AutoTool() { super("AutoTool", C, "Switches to the fastest hotbar tool while mining"); add(new Setting("Switch Back", true)); }
    @Override public void onTick(MinecraftClient mc) {
      var inv = mc.player.getInventory();
      if (mc.options.attackKey.isPressed() && mc.currentScreen == null && mc.crosshairTarget instanceof BlockHitResult hit) {
        BlockState st = mc.world.getBlockState(hit.getBlockPos());
        if (st.isAir()) return;
        int best = inv.selectedSlot; float bs = inv.getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) { float s = inv.getStack(i).getMiningSpeedMultiplier(st); if (s > bs + 0.01f) { bs = s; best = i; } }
        if (best != inv.selectedSlot) { if (prev < 0) prev = inv.selectedSlot; inv.selectedSlot = best; }
      } else if (prev >= 0) { if (get("Switch Back").on()) inv.selectedSlot = prev; prev = -1; }
    }
    @Override public void onDisable() { prev = -1; }
  }

  public static class AutoExp extends Module {
    int t;
    static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    public AutoExp() { super("AutoExp", C, "Throws XP bottles from the hotbar while your armour is damaged"); add(new Setting("Delay (ticks)", 4, 1, 20)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player;
      if (mc.currentScreen != null || ++t < get("Delay (ticks)").i()) return;
      boolean dmg = false; for (EquipmentSlot s : ARMOR) if (p.getEquippedStack(s).isDamaged()) dmg = true;
      int slot = Inv.hotbar(s -> s.isOf(Items.EXPERIENCE_BOTTLE));
      if (!dmg || slot < 0) return;
      t = 0; int prev = p.getInventory().selectedSlot; float pitch = p.getPitch();
      p.getInventory().selectedSlot = slot; p.setPitch(90f);
      mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
      p.setPitch(pitch); p.getInventory().selectedSlot = prev;
    }
  }

  public static class ChestStealer extends Module {
    int t;
    public ChestStealer() { super("ChestStealer", C, "Moves everything out of an opened chest/barrel"); add(new Setting("Delay (ticks)", 1, 0, 10)).add(new Setting("Randomize", false)).add(new Setting("Auto Close", true)); }
    @Override public void onTick(MinecraftClient mc) {
      if (!(mc.currentScreen instanceof GenericContainerScreen gs)) { t = 0; return; }
      if (++t <= get("Delay (ticks)").i() + (get("Randomize").on() ? (int) (Math.random() * 3) : 0)) return;
      t = 0; GenericContainerScreenHandler h = gs.getScreenHandler();
      for (int i = 0; i < h.getRows() * 9; i++) if (h.getSlot(i).hasStack()) { mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player); return; }
      if (get("Auto Close").on()) mc.player.closeHandledScreen();
    }
  }

  public static class Nuker extends Module {
    BlockPos cur;
    public Nuker() { super("Nuker", C, "Breaks nearby blocks automatically"); add(new Setting("Range", 4, 1, 5)).add(new Setting("Blocks/Tick", 1, 1, 4)).add(new Setting("Mode", "All", "All", "Above Feet", "Same Level")); }
    boolean ok(MinecraftClient mc, BlockPos p, double r) {
      BlockState s = mc.world.getBlockState(p);
      if (s.isAir() || !s.getFluidState().isEmpty() || s.getHardness(mc.world, p) < 0) return false;
      if (p.getSquaredDistance(mc.player.getEyePos()) > r * r) return false;
      int fy = mc.player.getBlockY(); Setting m = get("Mode");
      return !(m.is("Above Feet") && p.getY() < fy) && !(m.is("Same Level") && p.getY() != fy && p.getY() != fy + 1);
    }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.currentScreen != null) return;
      int r = get("Range").i(); double rr = r;
      if (!mc.player.isCreative()) {
        if (cur == null || !ok(mc, cur, rr)) {
          cur = null; double bd = Double.MAX_VALUE;
          for (BlockPos p : BlockPos.iterateOutwards(mc.player.getBlockPos(), r, r, r)) if (ok(mc, p, rr)) { double d = p.getSquaredDistance(mc.player.getEyePos()); if (d < bd) { bd = d; cur = p.toImmutable(); } }
        }
        if (cur != null) { mc.interactionManager.updateBlockBreakingProgress(cur, Direction.UP); mc.player.swingHand(Hand.MAIN_HAND); }
      } else {
        int n = get("Blocks/Tick").i();
        for (BlockPos p : BlockPos.iterateOutwards(mc.player.getBlockPos(), r, r, r)) {
          if (n <= 0) break;
          if (ok(mc, p, rr)) { mc.interactionManager.attackBlock(p.toImmutable(), Direction.UP); n--; }
        }
      }
    }
    @Override public void onDisable() { cur = null; }
  }

  /** Lowers expensive video options for Android; restores the previous values when switched off. */
  public static class Optimize extends Module {
    boolean applied; int view, sim; double ent; ParticlesMode part; CloudRenderMode cloud; int blend; boolean shadows;
    public Optimize() {
      super("Optimize", C, "Lowers view distance, particles, clouds and entity distance for more FPS");
      add(new Setting("View Distance", 6, 2, 16)).add(new Setting("Simulation Distance", 5, 5, 12)).add(new Setting("Entity Distance %", 60, 50, 200, 10)).add(new Setting("Minimal Particles", true)).add(new Setting("No Clouds", true));
    }
    void apply(MinecraftClient mc) {
      var o = mc.options;
      view = o.getViewDistance().getValue(); sim = o.getSimulationDistance().getValue(); ent = o.getEntityDistanceScaling().getValue();
      part = o.getParticles().getValue(); cloud = o.getCloudRenderMode().getValue(); blend = o.getBiomeBlendRadius().getValue(); shadows = o.getEntityShadows().getValue();
      o.getViewDistance().setValue(Math.min(view, get("View Distance").i())); o.getSimulationDistance().setValue(Math.min(sim, get("Simulation Distance").i()));
      o.getEntityDistanceScaling().setValue(Math.min(ent, get("Entity Distance %").value / 100.0));
      if (get("Minimal Particles").on()) o.getParticles().setValue(ParticlesMode.MINIMAL);
      if (get("No Clouds").on()) o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
      o.getBiomeBlendRadius().setValue(0); o.getEntityShadows().setValue(false);
      applied = true;
    }
    @Override public void onEnable() { applied = false; }
    @Override public void onTick(MinecraftClient mc) { if (!applied) apply(mc); }
    @Override public void onDisable() {
      if (!applied) return;
      var o = MinecraftClient.getInstance().options; applied = false;
      o.getViewDistance().setValue(view); o.getSimulationDistance().setValue(sim); o.getEntityDistanceScaling().setValue(ent);
      o.getParticles().setValue(part); o.getCloudRenderMode().setValue(cloud); o.getBiomeBlendRadius().setValue(blend); o.getEntityShadows().setValue(shadows);
    }
  }
}
