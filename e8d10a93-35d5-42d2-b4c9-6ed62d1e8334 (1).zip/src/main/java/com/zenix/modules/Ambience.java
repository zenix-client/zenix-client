package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Setting;
import com.zenix.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import java.util.Random;

/**
 * Client-side environment control. Time/weather are written every tick (client only, the server world is untouched).
 * Fog and sky colour are applied from mixins (BackgroundRendererMixin, ClientWorldMixin) which read the helpers below.
 */
public class Ambience extends Module {
  private final Random rnd = new Random();

  public Ambience() {
    super("Ambience", Category.RENDER, "Time, weather, sky colour, fog and particles");
    add(new Setting("Custom Time", false)).add(new Setting("Time", 6000, 0, 24000, 100));
    add(new Setting("Weather", "Vanilla", "Vanilla", "Clear", "Rain", "Thunder")).add(new Setting("Rain Strength %", 100, 10, 100, 10));
    add(new Setting("Fog", true)).add(new Setting("Fog Shape", "Sphere", "Sphere", "Cylinder"));
    add(new Setting("Fog Red", 120, 0, 255)).add(new Setting("Fog Green", 80, 0, 255)).add(new Setting("Fog Blue", 220, 0, 255));
    add(new Setting("Fog Rainbow", false));
    add(new Setting("Fog Distance %", 60, 10, 150)).add(new Setting("Fog Density %", 50, 0, 100));
    add(new Setting("Custom Sky", false));
    add(new Setting("Sky Red", 90, 0, 255)).add(new Setting("Sky Green", 60, 0, 255)).add(new Setting("Sky Blue", 170, 0, 255));
    add(new Setting("Particles", "Off", "Off", "Snow", "Ash", "Sparkles")).add(new Setting("Particle Amount", 3, 1, 10));
  }

  public boolean fogActive() { return enabled && get("Fog").on(); }
  public boolean skyActive() { return enabled && get("Custom Sky").on(); }

  /** fog colour 0..1 (rainbow aware) */
  public float[] fogRgb() {
    if (get("Fog Rainbow").on()) {
      int c = Colors.hsv((System.currentTimeMillis() % 12000L) / 12000f, 0.65f, 1f);
      return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
    }
    return new float[]{get("Fog Red").f() / 255f, get("Fog Green").f() / 255f, get("Fog Blue").f() / 255f};
  }
  public float[] skyRgb() { return new float[]{get("Sky Red").f() / 255f, get("Sky Green").f() / 255f, get("Sky Blue").f() / 255f}; }

  @Override public void onTick(MinecraftClient mc) {
    if (get("Custom Time").on()) mc.world.getLevelProperties().setTimeOfDay((long) get("Time").value);
    Setting w = get("Weather");
    if (!w.is("Vanilla")) {
      float s = get("Rain Strength %").f() / 100f;
      mc.world.setRainGradient(w.is("Clear") ? 0f : s);
      mc.world.setThunderGradient(w.is("Thunder") ? s : 0f);
    }
    Setting p = get("Particles");
    if (!p.is("Off") && mc.player != null) {
      ParticleEffect e = p.is("Snow") ? ParticleTypes.SNOWFLAKE : p.is("Ash") ? ParticleTypes.ASH : ParticleTypes.END_ROD;
      double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
      for (int i = 0; i < get("Particle Amount").i(); i++)
        mc.world.addParticle(e, px + (rnd.nextDouble() - 0.5) * 24, py + 1 + rnd.nextDouble() * 7, pz + (rnd.nextDouble() - 0.5) * 24, 0, p.is("Snow") ? -0.04 : -0.01, 0);
    }
  }
}
