package com.zenix.util;

import com.zenix.Module;
import com.zenix.Zenix;
import com.zenix.bots.BotManager;
import com.zenix.modules.BaseFinder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import java.util.*;

/** Chat commands starting with "." (never sent to the server when recognised). */
public final class CommandManager {
  private CommandManager() {}

  /** @return true if the message was a ZENIX command and must not be sent to the server. */
  public static boolean handle(String msg) {
    String[] a = msg.substring(1).trim().split("\\s+");
    if (a.length == 0 || a[0].isEmpty()) return false;
    String c = a[0].toLowerCase(Locale.ROOT);
    switch (c) {
      case "help" -> Chat.info(".toggle <module> | .bind <module> <key|none> | .friend add|remove|list <name> | .waypoint add|del|list <name> | .bf list|clear | .bots");
      case "toggle", "t" -> {
        Module m = a.length > 1 ? Zenix.byName(String.join(" ", Arrays.copyOfRange(a, 1, a.length))) : null;
        if (m == null) Chat.info("Unknown module");
        else if (m.planned) Chat.info(m.name + " is not implemented yet");
        else { m.toggle(); Chat.info(m.name + (m.enabled ? " \u00a7aON" : " \u00a7cOFF")); }
      }
      case "bind" -> {
        Module m = a.length > 2 ? Zenix.byName(a[1]) : null;
        if (m == null) { Chat.info("Usage: .bind <module> <key|none>"); break; }
        if (a[2].equalsIgnoreCase("none")) { m.key = -1; Chat.info(m.name + " unbound"); break; }
        try { m.key = InputUtil.fromTranslationKey("key.keyboard." + a[2].toLowerCase(Locale.ROOT)).getCode(); Chat.info(m.name + " bound to " + a[2].toUpperCase(Locale.ROOT)); Zenix.save(); }
        catch (Exception e) { Chat.info("Unknown key: " + a[2]); }
      }
      case "friend", "f" -> {
        if (a.length < 2) { Chat.info("Usage: .friend add|remove|list <name>"); break; }
        switch (a[1].toLowerCase(Locale.ROOT)) {
          case "add" -> { if (a.length > 2) Chat.info(Friends.add(a[2]) ? "Friend added: " + a[2] : "Already a friend"); }
          case "remove", "del" -> { if (a.length > 2) Chat.info(Friends.remove(a[2]) ? "Removed: " + a[2] : "Not a friend"); }
          default -> Chat.info("Friends: " + (Friends.all().isEmpty() ? "none" : String.join(", ", Friends.all())));
        }
      }
      case "waypoint", "wp" -> {
        if (a.length < 2) { Chat.info("Usage: .waypoint add|del|list <name>"); break; }
        switch (a[1].toLowerCase(Locale.ROOT)) {
          case "add" -> { if (a.length > 2) { Waypoints.add(a[2]); Chat.info("Waypoint saved: " + a[2]); } }
          case "del", "remove" -> { if (a.length > 2) Chat.info(Waypoints.remove(a[2]) ? "Waypoint removed" : "No such waypoint here"); }
          default -> { for (Waypoints.Point p : Waypoints.LIST) if (p.dim.equals(Waypoints.dim())) Chat.info(p.name + "  " + p.x + " " + p.y + " " + p.z); }
        }
      }
      case "bf", "basefinder" -> BaseFinder.command(a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "list");
      case "bots" -> Zenix.later(() -> MinecraftClient.getInstance().setScreen(new com.zenix.ui.BotsScreen(null)));
      default -> { return false; }
    }
    return true;
  }
}
