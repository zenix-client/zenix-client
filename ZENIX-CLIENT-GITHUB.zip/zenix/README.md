# ZENIX CLIENT — Minecraft Java 1.21.4 / Fabric

## Build on GitHub Actions
1. Upload the contents of this project to the root of your `zenix-client` repository (not the ZIP file itself).
2. Open **Actions → Build ZENIX CLIENT → Run workflow** (or push a commit).
3. Open the successful run and download artifact **zenix-client-jar**.
4. Extract the artifact and put the `.jar` in Zalith Launcher's `mods` folder for a Fabric 1.21.4 profile using Java 21.

A green workflow means compilation and the automated archive checks passed. It does not replace in-game testing.

## Status
The client contains implemented modules and some planned entries displayed as `SOON` in ClickGUI. Planned entries are not functional yet. See `docs/OBSIDIAN_AUDIT.md` for the feature-by-feature audit; this project does not contain the Obsidian JAR itself.
