package com.zenix.gui;

import com.zenix.ui.BotsScreen;
import com.zenix.ui.ClickGui;
import com.zenix.ui.Draw;
import com.zenix.ui.Fnt;
import com.zenix.ui.Theme;
import com.zenix.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class MainMenu extends Screen {
  static final String[] NAMES = {"SINGLEPLAYER", "MULTIPLAYER", "SETTINGS", "QUIT", "BOTS", "CLICKGUI"};
  static final String[] DESC = {"Create and explore worlds", "Join servers and play with friends", "Graphics, controls and audio", "Close the game", "Network bot sessions", "Modules and settings"};
  final float[] hov = new float[6]; long last;
  public MainMenu() { super(Text.literal("ZENIX")); }
  @Override public boolean shouldCloseOnEsc() { return false; }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}

  int[] card(int i) {
    int cw = Math.min(230, width / 2 - 20), ch = 72, gx = 12, slim = 28;
    int x0 = width / 2 - cw - gx / 2, y0 = height / 2 - ch - gx / 2 - slim / 2;
    if (i < 4) return new int[]{x0 + (i % 2) * (cw + gx), y0 + (i / 2) * (ch + gx), cw, ch};
    return new int[]{x0 + (i - 4) * (cw + gx), y0 + 2 * (ch + gx), cw, slim};
  }

  @Override public void render(DrawContext c, int mx, int my, float d) {
    long now = System.nanoTime(); float dt = last == 0 ? 0.016f : Math.min(0.1f, (now - last) / 1e9f); last = now;
    SplashScreen.paint(c, width, height);
    // title
    c.getMatrices().push(); c.getMatrices().translate(width / 2f, Math.max(10, height / 2f - 130), 0); c.getMatrices().scale(2.4f, 2.4f, 1f);
    c.drawCenteredTextWithShadow(textRenderer, Fnt.t("ZENIX CLIENT"), 0, 0, Theme.accentLight()); c.getMatrices().pop();
    c.drawCenteredTextWithShadow(textRenderer, Fnt.t("Minecraft 1.21.4  \u00b7  Fabric"), width / 2, (int) Math.max(10, height / 2f - 130) + 26, 0xFF6F6890);
    // user badge
    String user = client.getSession().getUsername(); int bw = Fnt.w(textRenderer, user) + 30;
    Draw.rrect(c, width - bw - 10, 10, bw, 22, 6, 0xCC120E1E, Theme.BORDER);
    c.fill(width - bw - 2, 17, width - bw + 4, 23, Theme.accent());
    c.drawText(textRenderer, Fnt.t(user), width - bw + 10, 17, Theme.TEXT, false);
    for (int i = 0; i < 6; i++) {
      int[] r = card(i); boolean h = Draw.in(mx, my, r[0], r[1], r[2], r[3]);
      hov[i] = Draw.approach(hov[i], h ? 1f : 0f, dt, 14f);
      Draw.rrect(c, r[0], r[1], r[2], r[3], 8, Colors.lerp(0xE60E0A18, 0xF0201838, hov[i]), Colors.lerp(Theme.BORDER, Theme.accent(), hov[i]));
      int bar = Math.round((r[3] - 16) * (0.35f + 0.65f * hov[i]));
      Draw.rrect(c, r[0] + 6, r[1] + (r[3] - bar) / 2, 3, bar, 1, Theme.accent());
      if (i < 4) {
        c.drawCenteredTextWithShadow(textRenderer, Fnt.t("" + NAMES[i]), r[0] + r[2] / 2, r[1] + 26, Colors.lerp(Theme.TEXT, 0xFFFFFFFF, hov[i]));
        c.drawCenteredTextWithShadow(textRenderer, Fnt.t(DESC[i]), r[0] + r[2] / 2, r[1] + 42, Colors.lerp(Theme.MUTED, Theme.accentLight(), hov[i]));
      } else c.drawCenteredTextWithShadow(textRenderer, Fnt.t("" + NAMES[i] + "\u00a7r  " + DESC[i]), r[0] + r[2] / 2, r[1] + 10, Colors.lerp(Theme.MUTED, Theme.TEXT, hov[i]));
    }
    c.drawCenteredTextWithShadow(textRenderer, Fnt.t("Right Shift in-game opens the ClickGUI  \u00b7  chat commands start with '.'  (.help)"), width / 2, height - 22, 0xFF4F4870);
  }

  @Override public boolean mouseClicked(double mx, double my, int b) {
    for (int i = 0; i < 6; i++) { int[] r = card(i);
      if (Draw.in(mx, my, r[0], r[1], r[2], r[3])) {
        switch (i) { case 0 -> client.setScreen(new SelectWorldScreen(this)); case 1 -> client.setScreen(new MultiplayerScreen(this));
          case 2 -> client.setScreen(new OptionsScreen(this, client.options)); case 3 -> client.scheduleStop();
          case 4 -> client.setScreen(new BotsScreen(this)); default -> client.setScreen(new ClickGui()); }
        return true; } }
    return false;
  }
}
