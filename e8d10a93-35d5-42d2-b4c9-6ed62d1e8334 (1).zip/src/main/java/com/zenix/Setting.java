package com.zenix;

/** One configurable value of a module: toggle, slider or mode list. Mode values are stored as an index. */
public class Setting {
  public final String name;
  public double value, min, max, step = 1;
  public final boolean bool;
  public final String[] modes; // null unless this is a mode setting

  public Setting(String n, boolean v) { name = n; bool = true; modes = null; value = v ? 1 : 0; }
  public Setting(String n, double v, double min, double max) { this(n, v, min, max, 1); }
  public Setting(String n, double v, double min, double max, double step) {
    name = n; bool = false; modes = null; value = v; this.min = min; this.max = max; this.step = step;
  }
  /** Mode setting: def must be one of modes. */
  public Setting(String n, String def, String... modes) {
    name = n; bool = false; this.modes = modes; this.min = 0; this.max = modes.length - 1;
    int i = 0; for (int k = 0; k < modes.length; k++) if (modes[k].equals(def)) i = k;
    value = i;
  }

  public boolean isMode() { return modes != null; }
  public boolean on() { return value > 0.5; }
  public float f() { return (float) value; }
  public int i() { return (int) Math.round(value); }
  public String mode() { return modes == null ? "" : modes[Math.max(0, Math.min(modes.length - 1, i()))]; }
  public boolean is(String m) { return isMode() && mode().equals(m); }

  public void set(double v) {
    if (bool) { value = v > 0.5 ? 1 : 0; return; }
    v = Math.max(min, Math.min(max, v));
    if (step > 0) v = min + Math.round((v - min) / step) * step;
    value = Math.max(min, Math.min(max, v));
  }
  public void cycle(int dir) {
    if (!isMode()) return;
    value = (i() + dir + modes.length) % modes.length;
  }
  public String display() {
    if (bool) return on() ? "On" : "Off";
    if (isMode()) return mode();
    if (step >= 1) return String.valueOf((int) Math.round(value));
    return String.format(java.util.Locale.ROOT, step >= 0.1 ? "%.1f" : "%.2f", value);
  }
}
