package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.ui.ClickGui;
import com.zenix.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import java.util.Locale;

public final class MiscModules {
  private MiscModules() {}
  static final Category C = Category.MISC;

  public static void register(List<Module> l) {
    l.add(new AutoLeave()); l.add(new AutoTPAccept()); MiscExtras.register(l); l.add(new ClickGUIModule());
    String server = "Server-specific; needs the target server's exact messages/GUI to be implemented honestly";
    for (String n : new String[]{"AutoDuel", "AutoJoin", "AutoWarden", "ServerAssist", "ServerRPSpoofer", "UseTracker", "TabExpert"}) l.add(Module.planned(n, C, server));
    l.add(Module.planned("AutoPilot", C, "Needs a pathfinder (Baritone is not bundled)"));
    l.add(Module.planned("FreeCam", C, "Camera detach hook not verified for 1.21.4 yet"));
    l.add(Module.planned("NameProtect", C, "Text-render hook not verified for 1.21.4 yet"));
    l.add(Module.planned("RPC", C, "Needs a Discord IPC library; none bundled"));
    l.add(Module.planned("Sound", C, "Not implemented yet")); l.add(Module.planned("ThrowXP", C, "Use AutoExp (Player) for XP bottles"));
  }

  public static class ClickGUIModule extends Module {
    public ClickGUIModule() {
      super("ClickGUI", C, "Opens this menu (default key: Right Shift)");
      key = GLFW.GLFW_KEY_RIGHT_SHIFT; enabled = true;
      add(new Setting("Accent", "Violet", "Violet", "Indigo", "Lavender")).add(new Setting("Animations", true));
    }
    @Override public void onKey(MinecraftClient mc) { mc.setScreen(new ClickGui()); }
  }

  public static class AutoLeave extends Module {
    public AutoLeave() {
      super("AutoLeave", C, "Leaves when your health is low or a stranger comes close");
      add(new Setting("Min Health (hearts)", 4, 0, 19)).add(new Setting("Player Radius", 0, 0, 64)).add(new Setting("Action", "Disconnect", "Disconnect", "/hub", "/spawn"));
    }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; String why = null;
      if (get("Min Health (hearts)").i() > 0 && p.getHealth() / 2f <= get("Min Health (hearts)").f()) why = "low health";
      int rad = get("Player Radius").i();
      if (why == null && rad > 0) for (PlayerEntity o : mc.world.getPlayers())
        if (o != p && p.distanceTo(o) <= rad && !Friends.is(o.getName().getString()) && !CombatModules.AntiBot.isBot(o)) { why = o.getName().getString() + " nearby"; break; }
      if (why == null) return;
      enabled = false;
      Setting a = get("Action");
      if (a.is("Disconnect") && mc.getNetworkHandler() != null) mc.getNetworkHandler().getConnection().disconnect(Text.literal("ZENIX AutoLeave: " + why));
      else if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatCommand(a.mode().substring(1));
    }
  }

  public static class AutoTPAccept extends Module {
    int wait = -1;
    public AutoTPAccept() { super("AutoTPAccept", C, "Sends /tpaccept when a teleport request arrives"); add(new Setting("Friends Only", true)).add(new Setting("Delay (ticks)", 10, 0, 60)); }
    @Override public void onChat(String m) {
      String s = m.toLowerCase(Locale.ROOT);
      if (!(s.contains("tpa") || s.contains("teleport") || s.contains("\u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442"))) return;
      if (get("Friends Only").on()) { boolean f = false; for (String n : Friends.all()) if (s.contains(n)) f = true; if (!f) return; }
      wait = get("Delay (ticks)").i();
    }
    @Override public void onTick(MinecraftClient mc) {
      if (wait < 0) return;
      if (wait-- == 0 && mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatCommand("tpaccept");
    }
  }
}
