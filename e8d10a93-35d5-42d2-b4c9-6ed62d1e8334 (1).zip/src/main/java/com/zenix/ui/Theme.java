package com.zenix.ui;

import com.zenix.Zenix;

/** Purple/black palette. The accent can be switched in the ClickGUI module (all variants are purple-family, no pink). */
public final class Theme {
  private Theme() {}
  public static final int BG = 0xF20A0812, SIDEBAR = 0xFF0E0B18, PANEL = 0xFF120E1E, CARD = 0xFF181228, CARD_HOVER = 0xFF1F1833,
    ROW = 0xFF140F22, FIELD = 0xFF1A1428, BORDER = 0xFF2A2142, OFF = 0xFF3A3156, TEXT = 0xFFF1ECFF, MUTED = 0xFF8E86A8, DIM = 0xFF5E5778;
  static final int[][] ACCENTS = {{0xFF8B5CF6, 0xFF6D28D9, 0xFFA78BFA}, {0xFF6366F1, 0xFF4338CA, 0xFF818CF8}, {0xFFA78BFA, 0xFF7C3AED, 0xFFC4B5FD}};
  static int idx() { try { return Zenix.clickgui == null ? 0 : Zenix.clickgui.get("Accent").i(); } catch (Exception e) { return 0; } }
  public static int accent() { return ACCENTS[idx()][0]; }
  public static int accentDark() { return ACCENTS[idx()][1]; }
  public static int accentLight() { return ACCENTS[idx()][2]; }
  public static final int GOOD = 0xFF7DD3A8, BAD = 0xFFE5707E, WARN = 0xFFE9C46A;
}
