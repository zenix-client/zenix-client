package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.mixin.*;
import com.zenix.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import java.util.List;

public final class PlayerExtras {
  private PlayerExtras() {}
  static final Category C = Category.PLAYER;
  public static void register(List<Module> l) { l.add(new AutoEat()); l.add(new AutoFish()); l.add(new HelpMessage()); l.add(new NoDelay()); l.add(new NoPush()); }

  public static class AutoEat extends Module {
    int prev = -1;
    public AutoEat() { super("AutoEat", C, "Eats food from the hotbar when your hunger is low"); add(new Setting("Eat At Hunger <=", 14, 1, 19)); }
    static boolean bad(ItemStack s) {
      String id = Inv.id(s);
      return id.equals("rotten_flesh") || id.equals("spider_eye") || id.equals("pufferfish") || id.equals("poisonous_potato") || id.equals("chorus_fruit") || id.equals("suspicious_stew") || id.equals("raw_chicken");
    }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; var inv = p.getInventory();
      boolean hungry = p.getHungerManager().getFoodLevel() <= get("Eat At Hunger <=").i() && p.canConsume(false);
      if (hungry && mc.currentScreen == null) {
        int slot = inv.selectedSlot;
        if (inv.getStack(slot).get(DataComponentTypes.FOOD) == null || bad(inv.getStack(slot))) {
          slot = Inv.hotbar(s -> s.get(DataComponentTypes.FOOD) != null && !bad(s));
          if (slot < 0) { stop(mc); return; }
          if (prev < 0) prev = inv.selectedSlot; inv.selectedSlot = slot;
        }
        mc.options.useKey.setPressed(true);
      } else stop(mc);
    }
    void stop(MinecraftClient mc) {
      if (prev >= 0) { mc.options.useKey.setPressed(false); mc.player.getInventory().selectedSlot = prev; prev = -1; }
    }
    @Override public void onDisable() { MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player != null) stop(mc); }
  }

  public static class AutoFish extends Module {
    int cd;
    public AutoFish() { super("AutoFish", C, "Reels in and recasts the fishing rod when a fish bites"); add(new Setting("Recast Delay (ticks)", 20, 10, 80)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player;
      if (!p.getMainHandStack().isOf(Items.FISHING_ROD) || mc.currentScreen != null) return;
      if (cd > 0) { cd--; return; }
      FishingBobberEntity h = p.fishHook;
      if (h == null) { mc.interactionManager.interactItem(p, Hand.MAIN_HAND); cd = get("Recast Delay (ticks)").i(); return; }
      if (h.age > 20 && h.isTouchingWater() && h.getVelocity().y < -0.05) { mc.interactionManager.interactItem(p, Hand.MAIN_HAND); cd = get("Recast Delay (ticks)").i(); }
    }
  }

  public static class HelpMessage extends Module {
    public HelpMessage() { super("HelpMessage", C, "Sends your coordinates to chat (bind a key)"); oneShot = true; add(new Setting("Prefix", "None", "None", "!")); }
    @Override public void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance(); enabled = false;
      if (mc.player == null || mc.getNetworkHandler() == null) return;
      String pre = get("Prefix").is("!") ? "!" : "";
      mc.getNetworkHandler().sendChatMessage(pre + "Help! " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
    }
  }

  /** Needs the accessor mixins (optional mixin config); if they failed to load the module disables itself with a chat message. */
  public static class NoDelay extends Module {
    public NoDelay() { super("NoDelay", C, "Removes jump delay, XP-bottle use delay and block-break delay"); add(new Setting("Jump", true)).add(new Setting("XP Bottle Use", true)).add(new Setting("Block Break", false)); }
    @Override public void onTick(MinecraftClient mc) {
      if (get("Jump").on()) ((LivingEntityAccessor) mc.player).zenix$setJumpingCooldown(0);
      if (get("XP Bottle Use").on() && mc.player.getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE)) ((MinecraftClientAccessor) mc).zenix$setItemUseCooldown(0);
      if (get("Block Break").on()) ((InteractionManagerAccessor) mc.interactionManager).zenix$setBlockBreakingCooldown(0);
    }
  }

  public static class NoPush extends Module {
    static NoPush I;
    public NoPush() { super("NoPush", C, "Other entities cannot push you around"); I = this; }
    public static boolean active() { return I != null && I.enabled; }
  }
}
