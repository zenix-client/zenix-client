package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.List;

public final class CombatModules {
  private CombatModules() {}
  static final Category C = Category.COMBAT;

  public static void register(List<Module> l) {
    l.add(new AntiBot()); l.add(new Aura()); l.add(new AutoArmor()); l.add(new AutoTotem()); l.add(new ClickPearl());
    l.add(new Criticals()); CombatExtras.register(l); l.add(new NoFriendDamage()); l.add(new Suicide()); l.add(new TriggerBot());
    String hook = "Needs a packet/entity hook whose 1.21.4 signatures are not verified yet";
    String spec = "Not implemented yet";
    l.add(Module.planned("AutoCrystal", C, spec)); l.add(Module.planned("AutoPotions", C, "Potion component API not verified yet"));
    l.add(Module.planned("AutoWeb", C, spec));
    l.add(Module.planned("CrossbowRapid", C, spec)); l.add(Module.planned("CrystalHelper", C, spec));
    l.add(Module.planned("Knockback", C, hook)); l.add(Module.planned("NoInteract", C, spec));
    l.add(Module.planned("ShiftTap", C, spec)); l.add(Module.planned("TargetPearl", C, spec));
    l.add(Module.planned("Velocity", C, hook));
  }

  // ------------------------------------------------------------------------------------------------ AntiBot
  public static class AntiBot extends Module {
    static AntiBot I;
    public AntiBot() {
      super("AntiBot", C, "Marks fake/NPC players so Aura, TriggerBot and others skip them");
      I = this; add(new Setting("Tab List", true)).add(new Setting("Invalid Name", true));
    }
    public static boolean isBot(Entity e) {
      if (I == null || !I.enabled || !(e instanceof PlayerEntity p)) return false;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (I.get("Tab List").on() && mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) == null) return true;
      return I.get("Invalid Name").on() && !p.getName().getString().matches("[A-Za-z0-9_]{1,16}");
    }
  }

  // ------------------------------------------------------------------------------------------------ Criticals
  public static class Criticals extends Module {
    static Criticals I;
    public Criticals() { super("Criticals", C, "Aura/TriggerBot only attack while falling (real critical hits)"); I = this; }
    public static boolean gate() { return I != null && I.enabled; }
    public static boolean ready(PlayerEntity p) {
      return p.fallDistance > 0.0f && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater() && !p.hasVehicle();
    }
  }

  // ------------------------------------------------------------------------------------------------ Aura
  public static class Aura extends Module {
    public static LivingEntity target;
    public Aura() {
      super("Aura", C, "Attacks the best target in range with cooldown-aware hits");
      add(new Setting("Range", 4.2, 2.5, 6.0, 0.1)).add(new Setting("Cooldown %", 92, 50, 100, 1));
      add(new Setting("Players", true)).add(new Setting("Mobs", false)).add(new Setting("Animals", false)).add(new Setting("Invisible", false));
      add(new Setting("Through Walls", false)).add(new Setting("FOV", 360, 30, 360, 10));
      add(new Setting("Sort", "Distance", "Distance", "Health"));
      add(new Setting("Rotation", "Smooth", "Snap", "Smooth", "None")).add(new Setting("Rotate Speed", 45, 5, 180, 5));
    }
    @Override public void onDisable() { target = null; }
    @Override public void onTick(MinecraftClient mc) {
      target = null;
      if (mc.currentScreen != null) return;
      PlayerEntity p = mc.player;
      LivingEntity best = null; double bestKey = Double.MAX_VALUE;
      double range = get("Range").value, fov = get("FOV").value;
      for (Entity e : mc.world.getEntities()) {
        if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
        if (e instanceof PlayerEntity pe) {
          if (!get("Players").on() || pe.isSpectator() || Friends.is(pe.getName().getString()) || AntiBot.isBot(pe)) continue;
        } else if (e instanceof Monster) { if (!get("Mobs").on()) continue; }
        else if (e instanceof AnimalEntity) { if (!get("Animals").on()) continue; }
        else continue;
        if (e.isInvisible() && !get("Invisible").on()) continue;
        double dist = p.distanceTo(e);
        if (dist > range) continue;
        if (!get("Through Walls").on() && !p.canSee(e)) continue;
        if (fov < 360) {
          Vec3d to = e.getBoundingBox().getCenter().subtract(p.getEyePos());
          float yaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90);
          if (Math.abs(MathHelper.wrapDegrees(yaw - p.getYaw())) > fov / 2) continue;
        }
        double key = get("Sort").is("Health") ? le.getHealth() : dist;
        if (key < bestKey) { bestKey = key; best = le; }
      }
      target = best;
      if (best == null) return;
      Setting rot = get("Rotation");
      if (!rot.is("None")) face(mc, best, rot.is("Snap") ? 0 : get("Rotate Speed").f());
      if (p.getAttackCooldownProgress(0.5f) < get("Cooldown %").f() / 100f) return;
      if (Criticals.gate() && !Criticals.ready(p)) return;
      mc.interactionManager.attackEntity(p, best);
      p.swingHand(Hand.MAIN_HAND);
    }
    static void face(MinecraftClient mc, Entity t, float maxStep) {
      PlayerEntity p = mc.player;
      Vec3d to = t.getBoundingBox().getCenter().subtract(p.getEyePos());
      float yaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90), pitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z)));
      float dy = MathHelper.wrapDegrees(yaw - p.getYaw()), dp = pitch - p.getPitch();
      if (maxStep > 0) { dy = MathHelper.clamp(dy, -maxStep, maxStep); dp = MathHelper.clamp(dp, -maxStep, maxStep); }
      p.setYaw(p.getYaw() + dy); p.setPitch(MathHelper.clamp(p.getPitch() + dp, -90f, 90f));
    }
  }

  // ------------------------------------------------------------------------------------------------ TriggerBot
  public static class TriggerBot extends Module {
    public TriggerBot() {
      super("TriggerBot", C, "Attacks whatever your crosshair is on when the cooldown is ready");
      add(new Setting("Cooldown %", 95, 50, 100, 1)).add(new Setting("Players Only", true)).add(new Setting("Smart Crits", false)).add(new Setting("Reset Sprint", false));
    }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.currentScreen != null) return;
      Entity t = mc.targetedEntity;
      if (!(t instanceof LivingEntity le) || !le.isAlive()) return;
      if (get("Players Only").on() && !(t instanceof PlayerEntity)) return;
      if (t instanceof PlayerEntity pe && (Friends.is(pe.getName().getString()) || AntiBot.isBot(pe))) return;
      PlayerEntity p = mc.player;
      if (p.getAttackCooldownProgress(0.5f) < get("Cooldown %").f() / 100f) return;
      if ((Criticals.gate() || get("Smart Crits").on()) && !Criticals.ready(p)) return;
      mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND);
      if (get("Reset Sprint").on()) p.setSprinting(false);
    }
  }

  // ------------------------------------------------------------------------------------------------ AutoArmor
  public static class AutoArmor extends Module {
    int timer;
    static final String[] PIECE = {"_helmet", "_chestplate", "_leggings", "_boots"};
    static final EquipmentSlot[] SLOT = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    public AutoArmor() { super("AutoArmor", C, "Equips the best armour from your inventory"); add(new Setting("Delay (ticks)", 4, 1, 20)); }
    /** armour tier by item id; 0 = not armour of this piece */
    static double score(net.minecraft.item.ItemStack s, int piece) {
      if (s.isEmpty()) return 0;
      String id = Inv.id(s); if (!id.endsWith(PIECE[piece])) return 0;
      if (id.startsWith("netherite")) return 5; if (id.startsWith("diamond")) return 4; if (id.startsWith("iron")) return 3;
      if (id.startsWith("chainmail")) return 2.5; if (id.startsWith("golden")) return 2; if (id.startsWith("turtle")) return 1.5; return 1;
    }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.currentScreen != null || --timer > 0) return;
      PlayerEntity p = mc.player;
      for (int i = 0; i < 4; i++) {
        double cur = score(p.getEquippedStack(SLOT[i]), i), bestS = cur; int bestSlot = -1;
        for (int k = 0; k < 36; k++) { double s = score(p.getInventory().getStack(k), i); if (s > bestS) { bestS = s; bestSlot = k; } }
        if (bestSlot < 0) continue;
        int sync = p.playerScreenHandler.syncId;
        if (cur > 0) mc.interactionManager.clickSlot(sync, 5 + i, 0, SlotActionType.QUICK_MOVE, p); // take the worse piece off first
        else mc.interactionManager.clickSlot(sync, Inv.screenSlot(bestSlot), 0, SlotActionType.QUICK_MOVE, p);
        timer = get("Delay (ticks)").i(); return;
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ AutoTotem
  public static class AutoTotem extends Module {
    int timer;
    public AutoTotem() {
      super("AutoTotem", C, "Keeps a Totem of Undying in your off-hand");
      add(new Setting("Health (hearts)", 20, 1, 20)).add(new Setting("Crystal Radius", 0, 0, 12)).add(new Setting("Fall Height", 0, 0, 30)).add(new Setting("Delay (ticks)", 2, 1, 20));
    }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player;
      if (mc.currentScreen != null || --timer > 0 || p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
      boolean danger = (p.getHealth() + p.getAbsorptionAmount()) / 2f <= get("Health (hearts)").f();
      int cr = get("Crystal Radius").i();
      if (!danger && cr > 0) for (net.minecraft.entity.Entity e : mc.world.getEntities()) if (e instanceof net.minecraft.entity.decoration.EndCrystalEntity && p.distanceTo(e) <= cr) { danger = true; break; }
      int fh = get("Fall Height").i();
      if (!danger && fh > 0 && p.fallDistance >= fh) danger = true;
      if (!danger) return;
      int slot = Inv.any(s -> s.isOf(Items.TOTEM_OF_UNDYING));
      if (slot < 0) return;
      mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.screenSlot(slot), 40, SlotActionType.SWAP, p);
      timer = get("Delay (ticks)").i();
    }
  }

  // ------------------------------------------------------------------------------------------------ ClickPearl / Suicide (one-shot)
  public static class ClickPearl extends Module {
    public ClickPearl() { super("ClickPearl", C, "Throws an ender pearl from the hotbar (bind a key; one press = one pearl)"); oneShot = true; }
    @Override public void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance(); enabled = false;
      if (mc.player == null) return;
      int s = Inv.hotbar(i -> i.isOf(Items.ENDER_PEARL));
      if (s < 0) { Chat.info("No ender pearl in the hotbar"); return; }
      int prev = mc.player.getInventory().selectedSlot;
      mc.player.getInventory().selectedSlot = s;
      mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
      mc.player.getInventory().selectedSlot = prev;
    }
  }
  public static class Suicide extends Module {
    public Suicide() { super("Suicide", C, "Sends /kill (works only where you may use it)"); oneShot = true; }
    @Override public void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance(); enabled = false;
      if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatCommand("kill");
    }
  }
}
