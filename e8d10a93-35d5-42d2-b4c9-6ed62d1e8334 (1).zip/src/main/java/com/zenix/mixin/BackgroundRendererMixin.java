package com.zenix.mixin;

import com.zenix.Zenix;
import com.zenix.modules.Ambience;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
  /** true when vanilla applies its own special fog (water, lava, powder snow, blindness, darkness): we must not override it */
  private static boolean zenix$special(Camera camera) {
    if (camera.getSubmersionType() != CameraSubmersionType.NONE) return true;
    return camera.getFocusedEntity() instanceof LivingEntity le
      && (le.hasStatusEffect(StatusEffects.BLINDNESS) || le.hasStatusEffect(StatusEffects.DARKNESS));
  }

  @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
  private static void zenix$fog(Camera camera, BackgroundRenderer.FogType fogType, Vector4f color, float viewDistance,
                                boolean thickenFog, float tickDelta, CallbackInfoReturnable<Fog> cir) {
    Ambience a = Zenix.ambience;
    if (a == null || !a.fogActive() || fogType != BackgroundRenderer.FogType.FOG_TERRAIN || zenix$special(camera)) return;
    Fog f = cir.getReturnValue();
    float end = Math.max(8f, viewDistance * a.get("Fog Distance %").f() / 100f);
    float start = end * (0.95f - 0.9f * a.get("Fog Density %").f() / 100f);
    float[] c = a.fogRgb();
    cir.setReturnValue(new Fog(start, end, a.get("Fog Shape").is("Cylinder") ? FogShape.CYLINDER : FogShape.SPHERE, c[0], c[1], c[2], f.alpha()));
  }

  // keeps the clear colour equal to the fog colour so there is no visible seam at the horizon
  @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
  private static void zenix$fogColor(CallbackInfoReturnable<Vector4f> cir) {
    Ambience a = Zenix.ambience;
    if (a == null || !a.fogActive()) return;
    if (zenix$special(MinecraftClient.getInstance().gameRenderer.getCamera())) return;
    float[] c = a.fogRgb();
    cir.setReturnValue(new Vector4f(c[0], c[1], c[2], 1f));
  }
}
