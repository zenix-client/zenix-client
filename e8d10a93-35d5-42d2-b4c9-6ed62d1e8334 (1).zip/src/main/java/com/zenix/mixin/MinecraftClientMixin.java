package com.zenix.mixin;
import com.zenix.gui.SplashScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
  @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
  private Screen zenix$title(Screen s) { return s != null && s.getClass() == TitleScreen.class ? new SplashScreen() : s; }
}
